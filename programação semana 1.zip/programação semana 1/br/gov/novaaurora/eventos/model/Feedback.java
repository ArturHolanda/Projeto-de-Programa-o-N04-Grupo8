package br.gov.novaaurora.eventos.model;

public class Feedback {
    private int id;
    private Participante participante;
    private String comentario;
    private String data;

    public Feedback(int id, Participante participante, String comentario, String data) {
        this.id = id;
        this.participante = participante;
        this.comentario = comentario;
        this.data = data;
    }

    public int getId() { return id; }
    public Participante getParticipante() { return participante; }
    public String getComentario() { return comentario; }
    public String getData() { return data; }
}
