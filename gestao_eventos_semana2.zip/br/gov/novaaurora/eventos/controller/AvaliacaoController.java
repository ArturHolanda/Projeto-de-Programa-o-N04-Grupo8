package br.gov.novaaurora.eventos.controller;

import br.gov.novaaurora.eventos.model.Avaliacao;
import br.gov.novaaurora.eventos.model.Evento;
import br.gov.novaaurora.eventos.service.AvaliacaoService;

public class AvaliacaoController {
    private AvaliacaoService avaliacaoService = new AvaliacaoService();

    public void registrarAvaliacao(Avaliacao avaliacao) {
        avaliacaoService.adicionarAvaliacao(avaliacao);
    }

    public void mostrarMediaEvento(Evento evento) {
        double media = avaliacaoService.calcularMediaPorEvento(evento);
        System.out.println("⭐ Média de avaliações para o evento '" + evento.getNome() + "': " + media);
    }
}
