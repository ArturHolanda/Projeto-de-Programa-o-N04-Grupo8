package br.gov.novaaurora.eventos.model;

import java.time.LocalDate;

public class Feedback {
    private int id;
    private Participante participante;
    private String comentario;
    private LocalDate data;

    public Feedback(int id, Participante participante, String comentario) {
        this.id = id;
        this.participante = participante;
        this.comentario = comentario;
        this.data = LocalDate.now();
    }

    public int getId() { return id; }
    public Participante getParticipante() { return participante; }
    public String getComentario() { return comentario; }
    public LocalDate getData() { return data; }
}
