package br.gov.novaaurora.eventos.model;

public class Avaliacao {
    private int id;
    private Participante participante;
    private Evento evento;
    private double nota;
    private String tipo;

    public Avaliacao(int id, Participante participante, Evento evento, double nota, String tipo) {
        this.id = id;
        this.participante = participante;
        this.evento = evento;
        this.nota = nota;
        this.tipo = tipo;
    }

    public int getId() { return id; }
    public Participante getParticipante() { return participante; }
    public Evento getEvento() { return evento; }
    public double getNota() { return nota; }
    public String getTipo() { return tipo; }
}
