package br.gov.novaaurora.eventos.service;

import br.gov.novaaurora.eventos.model.Avaliacao;
import br.gov.novaaurora.eventos.model.Evento;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AvaliacaoService {
    private List<Avaliacao> avaliacoes = new ArrayList<>();

    public boolean adicionarAvaliacao(Avaliacao avaliacao) {
        boolean jaExiste = avaliacoes.stream().anyMatch(a ->
            a.getParticipante().getId() == avaliacao.getParticipante().getId() &&
            a.getEvento().getId() == avaliacao.getEvento().getId() &&
            a.getTipo().equalsIgnoreCase(avaliacao.getTipo())
        );

        if (jaExiste) {
            System.out.println("⚠️ Avaliação já existente para este evento e participante.");
            return false;
        }

        avaliacoes.add(avaliacao);
        System.out.println("✅ Avaliação registrada com sucesso.");
        return true;
    }

    public List<Avaliacao> listarAvaliacoesPorEvento(Evento evento) {
        return avaliacoes.stream()
            .filter(a -> a.getEvento().getId() == evento.getId())
            .collect(Collectors.toList());
    }

    public double calcularMediaPorEvento(Evento evento) {
        List<Avaliacao> lista = listarAvaliacoesPorEvento(evento);
        if (lista.isEmpty()) return 0.0;
        return lista.stream().mapToDouble(Avaliacao::getNota).average().orElse(0.0);
    }
}
