package br.gov.novaaurora.eventos.model;

public class Evento {
    private int id;
    private String nome;
    private String data;

    public Evento(int id, String nome, String data) {
        this.id = id;
        this.nome = nome;
        this.data = data;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getData() { return data; }
}
