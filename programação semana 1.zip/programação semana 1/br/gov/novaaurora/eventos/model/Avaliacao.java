package br.gov.novaaurora.eventos.model;

public class Avaliacao {
    private int id;
    private Participante participante;
    private Evento evento;
    private double nota;

    public Avaliacao(int id, Participante participante, Evento evento, double nota) {
        this.id = id;
        this.participante = participante;
        this.evento = evento;
        this.nota = nota;
    }

    public int getId() { return id; }
    public Participante getParticipante() { return participante; }
    public Evento getEvento() { return evento; }
    public double getNota() { return nota; }
    public void setNota(double nota) { this.nota = nota; }
}
