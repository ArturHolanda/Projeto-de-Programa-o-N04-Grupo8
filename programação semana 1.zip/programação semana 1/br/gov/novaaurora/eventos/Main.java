package br.gov.novaaurora.eventos;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Sistema de Gestão de Eventos - Módulo Avaliação e Feedback ===");
    }
}
