package br.gov.novaaurora.eventos;

import br.gov.novaaurora.eventos.controller.*;
import br.gov.novaaurora.eventos.model.*;

public class Main {
    public static void main(String[] args) {
        AvaliacaoController avaliacaoController = new AvaliacaoController();
        FeedbackController feedbackController = new FeedbackController();

        Participante p1 = new Participante(1, "João", "joao@email.com");
        Evento e1 = new Evento(1, "Workshop Java", "20/10/2025");

        Avaliacao a1 = new Avaliacao(1, p1, e1, 4.5, "evento");
        avaliacaoController.registrarAvaliacao(a1);

        Avaliacao a2 = new Avaliacao(2, p1, e1, 3.0, "evento");
        avaliacaoController.registrarAvaliacao(a2);

        avaliacaoController.mostrarMediaEvento(e1);

        Feedback f1 = new Feedback(1, p1, "Excelente organização!");
        feedbackController.registrarFeedback(f1);

        feedbackController.exibirRelatorioSatisfacao();
    }
}
