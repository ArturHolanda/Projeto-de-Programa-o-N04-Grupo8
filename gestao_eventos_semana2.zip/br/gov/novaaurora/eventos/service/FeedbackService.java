package br.gov.novaaurora.eventos.service;

import br.gov.novaaurora.eventos.model.Feedback;
import java.util.ArrayList;
import java.util.List;

public class FeedbackService {
    private List<Feedback> feedbacks = new ArrayList<>();

    public void adicionarFeedback(Feedback feedback) {
        feedbacks.add(feedback);
        System.out.println("✅ Feedback registrado em " + feedback.getData());
    }

    public List<Feedback> listarFeedbacks() {
        return feedbacks;
    }

    public void gerarRelatorioSatisfacao() {
        System.out.println("=== Relatório de Feedbacks ===");
        for (Feedback f : feedbacks) {
            System.out.println("- [" + f.getData() + "] " + f.getParticipante().getNome() + ": " + f.getComentario());
        }
    }
}
