package br.gov.novaaurora.eventos.controller;

import br.gov.novaaurora.eventos.model.Feedback;
import br.gov.novaaurora.eventos.service.FeedbackService;

public class FeedbackController {
    private FeedbackService feedbackService = new FeedbackService();

    public void registrarFeedback(Feedback feedback) {
        feedbackService.adicionarFeedback(feedback);
    }

    public void exibirRelatorioSatisfacao() {
        feedbackService.gerarRelatorioSatisfacao();
    }
}
