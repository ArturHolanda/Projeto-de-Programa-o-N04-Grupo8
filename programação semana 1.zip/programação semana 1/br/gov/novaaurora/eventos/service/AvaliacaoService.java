package br.gov.novaaurora.eventos.service;

import br.gov.novaaurora.eventos.model.Avaliacao;
import java.util.ArrayList;
import java.util.List;

public class AvaliacaoService {
    private List<Avaliacao> avaliacoes = new ArrayList<>();

    public void adicionarAvaliacao(Avaliacao avaliacao) {
        avaliacoes.add(avaliacao);
    }

    public List<Avaliacao> listarAvaliacoes() {
        return avaliacoes;
    }
}
